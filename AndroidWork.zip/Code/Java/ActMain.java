package com.example.wanglung0820.order_2;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActMain extends AppCompatActivity {

    private View.OnClickListener btnorder_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(ActMain.this,ActDrink.class);
            startActivity(i);
        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_main);
        InitialComponent();
        openDB();
    }
    public void openDB(){
        SQLiteDatabase db = openOrCreateDatabase("table2",MODE_PRIVATE,null);
        try{
            MyTea tea = new MyTea();
            tea.onCreate(ActMain.this);
        }catch (Exception ex){

        }
    }

    private void InitialComponent() {
        btnorder = findViewById(R.id.btnorder);
        btnorder.setOnClickListener(btnorder_click);
    }
    Button btnorder;

}
