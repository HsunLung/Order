package com.example.wanglung0820.order_2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDB extends SQLiteOpenHelper{
    public MyDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE ttable1 " +
                "(_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name VARCHAR(30)," +
                "size VARCHAR(30)," +
                "sweet VARCHAR(30)," +
                "ice VARCHAR(30)," +
                "qty INTEGER," +
                "total INTEGER)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
