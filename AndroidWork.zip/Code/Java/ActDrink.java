package com.example.wanglung0820.order_2;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ActDrink extends AppCompatActivity {

    String[] showdb;

    public static final String SELECTED_INDEX = "SELECTED_INDEX";

    private View.OnClickListener btnTea1_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea1.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);
        }
    };

    private View.OnClickListener btnTea2_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea2.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);

        }
    };

    private View.OnClickListener btnTea3_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea3.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);

        }
    };

    private View.OnClickListener btnTea4_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea4.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);

        }
    };

    private View.OnClickListener btnTea5_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea5.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);

        }
    };

    private View.OnClickListener btnTea6_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea6.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);

        }
    };

    private View.OnClickListener btnTea7_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putString(ActDrink.SELECTED_INDEX,btnTea7.getText().toString());
            Intent i = new Intent(ActDrink.this,ActSelect.class);
            i.putExtras(b);
            startActivity(i);

        }
    };
    private View.OnClickListener btnDetails_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            showDB();
            AlertDialog.Builder builder = new AlertDialog.Builder(ActDrink.this);
            builder.setTitle("訂購明細");
            builder.setIcon(R.mipmap.ic_launcher);
            builder.setItems(showdb,null);
            builder.setPositiveButton("確定訂單", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            builder.setNegativeButton("取消",null);
            builder.show();


        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_drink);
        InitialComponent();
    }

    public void showDB(){
        MyDB helper = new MyDB(ActDrink.this,"ttable1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("ttable1",null,null,null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            showdb = new String[row];
            c.moveToFirst();
            for(int i = 0; i < row; i++){
                showdb[i] = c.getInt(0)+" ";
                showdb[i] += c.getString(1)+" ";
                showdb[i] += c.getString(2)+" ";
                showdb[i] += c.getString(3)+" ";
                showdb[i] += c.getString(4)+" ";
                showdb[i] += c.getInt(5)+"杯 ";
                showdb[i] += "$" + c.getInt(6)+"\n";
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    private void InitialComponent() {

        btnTea1 = findViewById(R.id.btnTea1);
        btnTea1.setOnClickListener(btnTea1_click);
        btnTea2 = findViewById(R.id.btnTea2);
        btnTea2.setOnClickListener(btnTea2_click);
        btnTea3 = findViewById(R.id.btnTea3);
        btnTea3.setOnClickListener(btnTea3_click);
        btnTea4 = findViewById(R.id.btnTea4);
        btnTea4.setOnClickListener(btnTea4_click);
        btnTea5 = findViewById(R.id.btnTea5);
        btnTea5.setOnClickListener(btnTea5_click);
        btnTea6 = findViewById(R.id.btnTea6);
        btnTea6.setOnClickListener(btnTea6_click);
        btnTea7 = findViewById(R.id.btnTea7);
        btnTea7.setOnClickListener(btnTea7_click);

        btnDetails = findViewById(R.id.btnDetails);
        btnDetails.setOnClickListener(btnDetails_click);

        //linview = findViewById(R.id.linview);
    }
    Button btnTea1;
    Button btnTea2;
    Button btnTea3;
    Button btnTea4;
    Button btnTea5;
    Button btnTea6;
    Button btnTea7;

    Button btnDetails;

    LinearLayout linview;
}
