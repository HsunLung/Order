package com.example.wanglung0820.order_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class MyTea {
    public void onCreate(Context act){
        try{
            MyTeaDB helper = new MyTeaDB(act, "table2",null,1);
            ContentValues values = new ContentValues();
            Cursor c = helper.getReadableDatabase().query("table2",null,null,null,null,null,null);
            if(c.getCount() == 0){
                values.put("name","紅茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
                values.put("name","綠茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
                values.put("name","奶茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
                values.put("name","烏龍茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
                values.put("name","青茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
                values.put("name","玫瑰花茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
                values.put("name","蜜茶");
                values.put("priceM",20);
                values.put("priceL",25);
                helper.getWritableDatabase().insert("table2",null,values);
            }

        }catch(Exception ex){

        }
    }
}
