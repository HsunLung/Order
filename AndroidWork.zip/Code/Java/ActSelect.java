package com.example.wanglung0820.order_2;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class ActSelect extends AppCompatActivity {
    int qty = 0, total = 0;
    String rdo1, rdo2, rdo3, str;
    MyDB helper;

    private RadioGroup.OnCheckedChangeListener radioPrice_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if(checkedId == R.id.radioPrice1)
                rdo1 = radioPrice1.getText().toString();
            else if (checkedId == R.id.radioPrice2)
                rdo1 = radioPrice2.getText().toString();

            Toast.makeText(ActSelect.this,rdo1,Toast.LENGTH_SHORT).show();
        }
    };

    private RadioGroup.OnCheckedChangeListener radioSweet_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if(checkedId == R.id.radioSweet1)
                rdo2 = radioSweet1.getText().toString();
            else if(checkedId == R.id.radioSweet2)
                rdo2 = radioSweet2.getText().toString();
            else if(checkedId == R.id.radioSweet3)
                rdo2 = radioSweet3.getText().toString();
            else if(checkedId == R.id.radioSweet4)
                rdo2 = radioSweet4.getText().toString();


            Toast.makeText(ActSelect.this,rdo2,Toast.LENGTH_SHORT).show();

        }
    };

    private RadioGroup.OnCheckedChangeListener radioIce_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if(checkedId == R.id.radioIce1)
                rdo3 = radioIce1.getText().toString();
            else if(checkedId == R.id.radioIce2)
                rdo3 = radioIce2.getText().toString();
            else if(checkedId == R.id.radioIce3)
                rdo3 = radioIce3.getText().toString();
            else if(checkedId == R.id.radioIce4)
                rdo3 = radioIce4.getText().toString();
            else if(checkedId == R.id.radioIce5)
                rdo3 = radioIce5.getText().toString();

            Toast.makeText(ActSelect.this,rdo3,Toast.LENGTH_SHORT).show();

        }
    };

    private View.OnClickListener btn1Plus_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try{
                searchData();
                qty++;
                txt1Count.setText(String.valueOf(qty));
                lblPrice.setText(String.valueOf("$"+(total * qty)));
            }catch(Exception ex){
                Toast.makeText(ActSelect.this,"請輸入正確資料",Toast.LENGTH_SHORT).show();
            }


        }
    };

    private View.OnClickListener btn1Minus_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try{
                if(qty > 0){
                    searchData();
                    qty--;
                    txt1Count.setText(String.valueOf(qty));
                    lblPrice.setText(String.valueOf("$"+(total * qty)));
                }
            }catch(Exception ex){
                Toast.makeText(ActSelect.this,"請輸入正確資料",Toast.LENGTH_SHORT).show();
            }

        }
    };

    private View.OnClickListener btnCancel_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(ActSelect.this, "取消訂購", Toast.LENGTH_SHORT).show();
            finish();
        }
    };

    private View.OnClickListener btnSendout_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            helper = new MyDB(ActSelect.this,"ttable1.db",null,1);
            ContentValues values = new ContentValues();
            values.put("name",str);
            values.put("size",rdo1);
            values.put("sweet",rdo2);
            values.put("ice",rdo3);
            values.put("qty",qty);
            values.put("total",(total*qty));

            long id = helper.getWritableDatabase().insert("ttable1",null,values);
            Toast.makeText(ActSelect.this,"訂購完成" + id ,Toast.LENGTH_SHORT).show();
            finish();

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_select);
        InitialComponent();

    }

    private String SetCountPlus(String Count){
        if(Count.equals(""))
            Count = "1";
        else
        if(Integer.parseInt(Count)>=0){
            int num = Integer.parseInt(Count);
            num++;
            Count = Integer.toString(num);
        }
        else
            Count = "1";
        return Count;
    }

    private String SetCountMinus(String Count){
        if(Count.equals(""))
            Count = "0";
        else
        if(Integer.parseInt(Count)>0){
            int num = Integer.parseInt(Count);
            num--;
            Count = Integer.toString(num);
        }
        else
            Count = "0";
        return Count;
    }

    public void searchData(){
        String test = "";
        Intent i = getIntent();
        Bundle bundle = i.getExtras();
        String data = bundle.getString(ActDrink.SELECTED_INDEX);

        str = "";
        for(int a=0; a<data.length(); a++){
            if(data.charAt(a) != ' ')
                str += data.charAt(a);
            else
                break;
        }

        if(rdo1.equals("M $20")){
            for(int a=0; a<data.length();){
                if(data.charAt(a) != '$')
                    a++;
                else{
                    for(int b=a+1; b<data.length(); b++)
                    {
                        if(data.charAt(b) != ' ')
                            test += data.charAt(b);
                        else
                            break;
                    }
                    break;
                }
            }
        }
        else{
            for(int a=data.length() - 1; a>=0;){
                if(data.charAt(a) != '$')
                    test += data.charAt(a--);
                else
                    break;
            }
            test = reverse(test);
        }
        total = Integer.parseInt(test);
    }


    public String reverse(String str){
        String test = "";
        for(int i=str.length() - 1; i>=0; i--)
            test += str.charAt(i);
        return test;
    }

    private void InitialComponent() {
        radioPrice = findViewById(R.id.radioPrice);
        radioPrice.setOnCheckedChangeListener(radioPrice_click);
        radioSweet = findViewById(R.id.radioSweet);
        radioSweet.setOnCheckedChangeListener(radioSweet_click);
        radioIce = findViewById(R.id.radioIce);
        radioIce.setOnCheckedChangeListener(radioIce_click);

        radioPrice1 = findViewById(R.id.radioPrice1);
        radioPrice2 = findViewById(R.id.radioPrice2);
        radioSweet1 = findViewById(R.id.radioSweet1);
        radioSweet2 = findViewById(R.id.radioSweet2);
        radioSweet3 = findViewById(R.id.radioSweet3);
        radioSweet4 = findViewById(R.id.radioSweet4);
        radioIce1 = findViewById(R.id.radioIce1);
        radioIce2 = findViewById(R.id.radioIce2);
        radioIce3 = findViewById(R.id.radioIce3);
        radioIce4 = findViewById(R.id.radioIce4);
        radioIce5 = findViewById(R.id.radioIce5);

        btn1Plus = findViewById(R.id.btn1Plus);
        btn1Plus.setOnClickListener(btn1Plus_click);
        btn1Minus = findViewById(R.id.btn1Minus);
        btn1Minus.setOnClickListener(btn1Minus_click);

        btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(btnCancel_click);
        btnSendout = findViewById(R.id.btnSendout);
        btnSendout.setOnClickListener(btnSendout_click);

        txt1Count = findViewById(R.id.txt1Count);

        lblPrice = findViewById(R.id.lblPrice);

    }
    RadioGroup radioPrice;
    RadioButton radioPrice1;
    RadioButton radioPrice2;

    RadioGroup radioSweet;
    RadioButton radioSweet1;
    RadioButton radioSweet2;
    RadioButton radioSweet3;
    RadioButton radioSweet4;

    RadioGroup radioIce;
    RadioButton radioIce1;
    RadioButton radioIce2;
    RadioButton radioIce3;
    RadioButton radioIce4;
    RadioButton radioIce5;

    Button btn1Plus;
    Button btn1Minus;

    Button btnCancel;
    Button btnSendout;

    EditText txt1Count;

    TextView lblPrice;

}
